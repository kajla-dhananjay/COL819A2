#!/bin/bash
g++ -Wall -Wextra -pedantic -lpthread main.cpp GHSNode.cpp GHSNode.h -o ghs
