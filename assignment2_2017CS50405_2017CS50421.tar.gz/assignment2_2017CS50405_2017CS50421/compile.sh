#!/bin/bash
a=$0
a=${a::-10}
g++ -Wall -Wextra -pedantic -lpthread ${a}main.cpp ${a}GHSNode.cpp ${a}GHSNode.h -o ${a}ghs
