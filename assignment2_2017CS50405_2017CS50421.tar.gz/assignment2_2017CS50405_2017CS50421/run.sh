#!/bin/bash
a=$0
a=${a::-6}
${a}ghs < $1 > $2
