#!/bin/bash
a=$1
b=$2
./ghs < $1 > $2
